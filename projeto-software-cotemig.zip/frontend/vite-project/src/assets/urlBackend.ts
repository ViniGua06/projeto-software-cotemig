const url = "http://localhost:2000";

export default url;
