import { InformModal } from "../components/InformModal";

export const NotAllowed = () => {
  return (
    <>
      <InformModal></InformModal>
    </>
  );
};
