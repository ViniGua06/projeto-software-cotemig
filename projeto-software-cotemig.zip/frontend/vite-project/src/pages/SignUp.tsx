import Form from "../components/Form/Form";
import Header from "../components/Header";

const SignUp = () => {
  return (
    <>
      <Header></Header>
      <Form opt="cadastrar"></Form>
    </>
  );
};

export default SignUp;
