import Header from "../components/Header";

const Churches = () => {
  return (
    <>
      <Header />
    </>
  );
};

export default Churches;
