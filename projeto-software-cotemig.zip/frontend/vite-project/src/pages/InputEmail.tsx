import Form from "../components/Form/Form";
import Header from "../components/Header";

const InputEmail = () => {
  return (
    <>
      <Header></Header>
      <Form opt="inputEmail"></Form>
    </>
  );
};

export default InputEmail;
