# Front do site da Igreja

Sempre antes de começar a codar:

1. Executar o comando `git pull`

Para rodar o projeto:

1. Executar o comando `cd frontend/vite-project`

2. Executar o comando `npm install`

3. Executar o comando `npm run dev`

Para atualizar suas mudanças:

1. Executar o comando `git add .`

2. Executar o comando `git commit -m "mensagem do commit"`, sendo a mensagem do commit de sua escolha

3. Executar o comando `git push -u origin alguma_branch`, sendo "alguma_branch" a branch que irá ser atualizada